package com.zainlashari.ydm.model

enum class DownloadState { QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED, CANCELLED }

data class DownloadItem(
    val id: String,
    val url: String,
    var fileName: String,
    var mimeType: String,
    var totalBytes: Long = -1L,
    var downloadedBytes: Long = 0L,
    var state: DownloadState = DownloadState.QUEUED,
    var speedBytesPerSec: Long = 0L,
    var etaSeconds: Long = -1L,
    var destinationUri: String? = null,
    var retryCount: Int = 0,
    var errorMessage: String? = null
) {
    val progressPercent: Int
        get() = if (totalBytes > 0) ((downloadedBytes * 100) / totalBytes).toInt() else -1

    fun toJson(): String {
        fun esc(s: String?) = (s ?: "").replace("\\", "\\\\").replace("\"", "\\\"")
        return """
            {"id":"${esc(id)}","url":"${esc(url)}","fileName":"${esc(fileName)}",
            "mimeType":"${esc(mimeType)}","totalBytes":$totalBytes,"downloadedBytes":$downloadedBytes,
            "state":"${state.name}","speedBytesPerSec":$speedBytesPerSec,"etaSeconds":$etaSeconds,
            "progressPercent":$progressPercent,"errorMessage":${if (errorMessage != null) "\"${esc(errorMessage)}\"" else "null"}}
        """.trimIndent().replace("\n", "")
    }
}
