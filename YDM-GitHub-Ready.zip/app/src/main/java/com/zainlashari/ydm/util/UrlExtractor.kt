package com.zainlashari.ydm.util

import java.util.regex.Pattern

/**
 * Pulls the first http/https URL out of arbitrary shared text.
 * Android share payloads are often "Check this out: https://youtu.be/xyz via YouTube"
 * rather than a bare URL, so we can't just trust EXTRA_TEXT verbatim.
 */
object UrlExtractor {

    private val URL_PATTERN: Pattern = Pattern.compile(
        "(https?://[\\w\\-./?=&%#:+~@!$'()*,;]+)",
        Pattern.CASE_INSENSITIVE
    )

    fun extractFirstUrl(text: String?): String? {
        if (text.isNullOrBlank()) return null
        val matcher = URL_PATTERN.matcher(text)
        if (matcher.find()) {
            var url = matcher.group(1) ?: return null
            // Trim common trailing punctuation that isn't part of the URL
            url = url.trimEnd('.', ',', ')', ']', '}', '"', '\'', '>')
            return url
        }
        return null
    }

    fun isHttpUrl(value: String?): Boolean {
        if (value.isNullOrBlank()) return false
        return value.startsWith("http://", ignoreCase = true) ||
            value.startsWith("https://", ignoreCase = true)
    }
}
