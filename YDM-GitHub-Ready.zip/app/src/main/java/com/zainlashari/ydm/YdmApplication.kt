package com.zainlashari.ydm

import android.app.Application
import com.zainlashari.ydm.util.NotificationHelper

class YdmApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.ensureChannels(this)
    }
}
