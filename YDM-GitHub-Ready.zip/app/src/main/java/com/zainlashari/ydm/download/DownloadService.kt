package com.zainlashari.ydm.download

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationCompat
import com.zainlashari.ydm.MainActivity
import com.zainlashari.ydm.R
import com.zainlashari.ydm.model.DownloadItem
import com.zainlashari.ydm.model.DownloadState
import com.zainlashari.ydm.util.NotificationHelper
import com.zainlashari.ydm.util.StorageHelper
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * Native download engine.
 *
 * Only downloads bytes from the exact URL it is given (direct/authorized file URLs,
 * e.g. an authorized CDN link, not a YouTube watch page). Range-request based, so
 * pause/resume/cancel/retry are all real, byte-accurate operations rather than
 * OS DownloadManager approximations.
 */
class DownloadService : Service() {

    inner class LocalBinder : Binder() {
        fun getService(): DownloadService = this@DownloadService
    }

    interface Listener {
        fun onProgress(item: DownloadItem)
        fun onStateChanged(item: DownloadItem)
    }

    private val binder = LocalBinder()
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private val items = ConcurrentHashMap<String, DownloadItem>()
    private val jobs = ConcurrentHashMap<String, Job>()
    // Queue mutations only ever happen inside synchronized(queue) blocks below, since
    // ArrayDeque itself isn't thread-safe and enqueue()/processQueue() can be entered
    // both from JS-bridge calls (background thread) and from download-completion
    // callbacks (coroutine dispatcher thread).
    private val queue = ArrayDeque<String>()
    private var listener: Listener? = null

    var simultaneousLimit: Int = 3
    /** Bytes/sec, 0 = unlimited. Applied per active download. */
    var speedLimitBytesPerSec: Long = 0L

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // If Android recreates this service while a download is active, restore
        // the foreground state before returning.
        if (jobs.values.any { it.isActive }) promoteToForegroundIfNeeded()
        return START_NOT_STICKY
    }

    fun setListener(l: Listener?) { listener = l }

    fun allItems(): List<DownloadItem> = items.values.sortedBy { it.id }

    fun getItem(id: String): DownloadItem? = items[id]

    fun enqueue(url: String, suggestedName: String?, mimeType: String?): String {
        promoteToForegroundIfNeeded()
        val id = System.currentTimeMillis().toString() + (0..999).random()
        val name = suggestedName?.takeIf { it.isNotBlank() } ?: guessFileName(url)
        val mime = mimeType?.takeIf { it.isNotBlank() } ?: guessMimeType(name)
        val item = DownloadItem(id = id, url = url, fileName = name, mimeType = mime)
        items[id] = item
        synchronized(queue) { queue.addLast(id) }
        emitState(item)
        processQueue()
        return id
    }

    fun pause(id: String) {
        jobs[id]?.cancel()
        items[id]?.let { it.state = DownloadState.PAUSED; emitState(it) }
        processQueue()
    }

    fun resume(id: String) {
        promoteToForegroundIfNeeded()
        items[id]?.let {
            if (it.state == DownloadState.PAUSED || it.state == DownloadState.FAILED) {
                it.state = DownloadState.QUEUED
                emitState(it)
                synchronized(queue) { if (!queue.contains(id)) queue.addLast(id) }
                processQueue()
            }
        }
    }

    fun cancel(id: String) {
        jobs[id]?.cancel()
        synchronized(queue) { queue.remove(id) }
        items[id]?.let {
            it.state = DownloadState.CANCELLED
            emitState(it)
            cleanupPartialFile(it)
        }
    }

    fun retry(id: String) {
        promoteToForegroundIfNeeded()
        items[id]?.let {
            it.retryCount += 1
            it.errorMessage = null
            it.state = DownloadState.QUEUED
            emitState(it)
            synchronized(queue) { if (!queue.contains(id)) queue.addLast(id) }
            processQueue()
        }
    }

    private fun activeCount(): Int = jobs.values.count { it.isActive }

    private fun promoteToForegroundIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID_SERVICE,
                buildServiceNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIF_ID_SERVICE, buildServiceNotification())
        }
    }

    private fun processQueue() {
        while (activeCount() < max(1, simultaneousLimit)) {
            val id = synchronized(queue) { queue.removeFirstOrNull() } ?: break
            val item = items[id] ?: continue
            if (item.state == DownloadState.CANCELLED) continue
            startDownload(item)
        }
    }

    private fun startDownload(item: DownloadItem) {
        item.state = DownloadState.DOWNLOADING
        emitState(item)
        val job = serviceScope.launch {
            try {
                runDownload(item)
                if (isActive) {
                    item.state = DownloadState.COMPLETED
                    emitState(item)
                    notifyStatus(item, "Download complete", item.fileName)
                }
            } catch (ce: CancellationException) {
                // Paused or cancelled elsewhere; state already set by pause()/cancel().
            } catch (e: Exception) {
                item.state = DownloadState.FAILED
                item.errorMessage = e.message ?: "Download failed"
                emitState(item)
                notifyStatus(item, "Download failed", item.fileName)
            } finally {
                jobs.remove(item.id)
                withContext(Dispatchers.Main) {
                    processQueue()
                    if (activeCount() == 0 && synchronized(queue) { queue.isEmpty() }) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                }
            }
        }
        jobs[item.id] = job
    }

    private suspend fun runDownload(item: DownloadItem) = withContext(Dispatchers.IO) {
        val tempFile = tempFileFor(item)
        val startOffset = if (tempFile.exists()) tempFile.length() else 0L
        item.downloadedBytes = startOffset

        val requestBuilder = Request.Builder().url(item.url)
        if (startOffset > 0) requestBuilder.header("Range", "bytes=$startOffset-")
        val response = client.newCall(requestBuilder.build()).execute()

        if (!response.isSuccessful && response.code != 206) {
            response.close()
            throw IllegalStateException("Server returned HTTP ${response.code}")
        }

        // A server may ignore Range and return 200. Never append a full response
        // to an existing partial file because that would corrupt the download.
        val actualOffset = if (startOffset > 0 && response.code == 206) startOffset else 0L
        if (actualOffset == 0L && startOffset > 0) {
            tempFile.delete()
            item.downloadedBytes = 0L
        } else {
            item.downloadedBytes = actualOffset
        }

        val body = response.body ?: throw IllegalStateException("Empty response body")
        val contentLength = body.contentLength()
        item.totalBytes = if (response.code == 206 && contentLength > 0) {
            contentLength + actualOffset
        } else if (contentLength > 0) {
            contentLength
        } else {
            -1L
        }

        val raf = RandomAccessFile(tempFile, "rw")
        raf.setLength(actualOffset)
        raf.seek(actualOffset)

        var lastEmit = System.currentTimeMillis()
        var bytesSinceLastEmit = 0L
        val minIntervalMs = if (speedLimitBytesPerSec > 0) 200L else 400L

        body.byteStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (isActive) {
                val read = input.read(buffer)
                if (read == -1) break
                raf.write(buffer, 0, read)
                item.downloadedBytes += read
                bytesSinceLastEmit += read

                if (speedLimitBytesPerSec > 0) {
                    val expectedMs = (bytesSinceLastEmit * 1000) / speedLimitBytesPerSec
                    val elapsed = System.currentTimeMillis() - lastEmit
                    if (expectedMs > elapsed) delay(expectedMs - elapsed)
                }

                val now = System.currentTimeMillis()
                val elapsed = now - lastEmit
                if (elapsed >= minIntervalMs) {
                    item.speedBytesPerSec = (bytesSinceLastEmit * 1000) / max(1, elapsed)
                    item.etaSeconds = if (item.totalBytes > 0 && item.speedBytesPerSec > 0)
                        (item.totalBytes - item.downloadedBytes) / item.speedBytesPerSec else -1
                    emitProgress(item)
                    lastEmit = now
                    bytesSinceLastEmit = 0
                }
            }
        }
        raf.close()
        response.close()

        if (!isActive) return@withContext // paused/cancelled mid-stream

        moveToFinalDestination(item, tempFile)
    }

    private fun tempFileFor(item: DownloadItem) =
        File(cacheDir, "ydm_partial_${item.id}")

    private fun moveToFinalDestination(item: DownloadItem, tempFile: File) {
        val treeUri = StorageHelper.getTreeUri(applicationContext)
        if (treeUri != null) {
            val doc = StorageHelper.createSafFile(applicationContext, item.fileName, item.mimeType)
            if (doc != null) {
                contentResolver.openOutputStream(doc.uri, "w")?.use { out ->
                    tempFile.inputStream().use { it.copyTo(out) }
                }
                item.destinationUri = doc.uri.toString()
                tempFile.delete()
                return
            }
        }
        // Fallback: app-scoped external files dir, no permission required.
        val destDir = StorageHelper.fallbackDir(applicationContext)
        destDir.mkdirs()
        val destFile = File(destDir, item.fileName)
        tempFile.copyTo(destFile, overwrite = true)
        tempFile.delete()
        item.destinationUri = destFile.absolutePath
    }

    private fun cleanupPartialFile(item: DownloadItem) {
        tempFileFor(item).delete()
    }

    private fun guessFileName(url: String): String {
        val last = Uri.parse(url).lastPathSegment
        return if (!last.isNullOrBlank()) last else "ydm_download_${System.currentTimeMillis()}"
    }

    private fun guessMimeType(fileName: String): String {
        val ext = MimeTypeMap.getFileExtensionFromUrl(fileName)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    // ---- Notifications ----

    private fun emitProgress(item: DownloadItem) {
        listener?.onProgress(item)
        updateProgressNotification(item)
    }

    private fun emitState(item: DownloadItem) {
        listener?.onStateChanged(item)
        if (item.state == DownloadState.DOWNLOADING) updateProgressNotification(item)
    }

    private fun buildServiceNotification(): Notification =
        NotificationCompat.Builder(this, NotificationHelper.CHANNEL_PROGRESS)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle("YDM")
            .setContentText("Download manager running")
            .setOngoing(true)
            .setSilent(true)
            .build()

    private fun updateProgressNotification(item: DownloadItem) {
        if (!NotificationHelper.canPostNotifications(this)) return
        val pct = item.progressPercent
        val builder = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_PROGRESS)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle(item.fileName)
            .setOngoing(item.state == DownloadState.DOWNLOADING)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppPendingIntent())

        if (pct >= 0) {
            builder.setProgress(100, pct, false)
            builder.setContentText("$pct% • ${formatSpeed(item.speedBytesPerSec)}")
        } else {
            builder.setProgress(0, 0, true)
            builder.setContentText(formatSpeed(item.speedBytesPerSec))
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(item.id.hashCode(), builder.build())
    }

    private fun notifyStatus(item: DownloadItem, title: String, text: String) {
        if (!NotificationHelper.canPostNotifications(this)) return
        val builder = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_STATUS)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openAppPendingIntent())
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(item.id.hashCode(), builder.build())
    }

    private fun openAppPendingIntent(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getActivity(this, 0, intent, flags)
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        if (bytesPerSec <= 0) return "—"
        val kb = bytesPerSec / 1024.0
        return if (kb < 1024) "%.0f KB/s".format(kb) else "%.1f MB/s".format(kb / 1024.0)
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val NOTIF_ID_SERVICE = 9001
        fun start(context: Context) {
            // The service is started normally while YDM is visible. It only
            // becomes a foreground service when enqueue() begins real work.
            context.startService(Intent(context, DownloadService::class.java))
        }
    }
}
