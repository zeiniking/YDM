package com.zainlashari.ydm

import android.os.Build
import android.provider.Settings
import android.webkit.JavascriptInterface
import com.zainlashari.ydm.overlay.OverlayService
import com.zainlashari.ydm.util.StorageHelper
import org.json.JSONObject

/**
 * Secure WebView <-> native bridge, injected as `window.AndroidBridge` — the exact
 * global name YDM.html already looks for (see `const AndroidBridge = window.AndroidBridge`
 * and the `bridge(method, ...args)` helper near the top of its script). Method names
 * and argument shapes below match what YDM.html actually calls; nothing here bypasses
 * authentication, DRM, or protected-stream extraction — it only manages direct URLs,
 * permissions, storage location, and native notifications/overlay.
 */
class WebAppInterface(private val activity: MainActivity) {

    // ---- Existing YDM.html hooks (browser-fallback aware) ----

    @JavascriptInterface
    fun showNotification(kind: String, title: String, body: String): Boolean {
        activity.runOnUiThread { activity.showSimpleNotification(title, body) }
        return true
    }

    @JavascriptInterface
    fun saveFile(filename: String, location: String): Boolean {
        // Browser-mode fallback path in YDM.html (blob download) isn't used natively —
        // native downloads are written directly by DownloadService via startNativeDownload.
        // Returning true here just tells YDM.html "handled", matching its existing check.
        return true
    }

    @JavascriptInterface
    fun pauseDownload(id: String) { /* legacy hook kept for compatibility; native downloads use pauseNativeDownload */ }

    @JavascriptInterface
    fun resumeDownload(id: String) { /* legacy hook kept for compatibility; native downloads use resumeNativeDownload */ }

    @JavascriptInterface
    fun receiveSharedUrl() { /* readiness ping only — actual delivery is MainActivity calling
        window.AndroidBridge_receiveSharedUrl(url) directly once a share Intent arrives */ }

    // ---- Native download engine ----

    @JavascriptInterface
    fun startNativeDownload(url: String, fileName: String?, mimeType: String?): String {
        var id = ""
        activity.runOnDownloadService { service -> id = service.enqueue(url, fileName, mimeType) }
        return id
    }

    @JavascriptInterface
    fun pauseNativeDownload(id: String) { activity.runOnDownloadService { it.pause(id) } }

    @JavascriptInterface
    fun resumeNativeDownload(id: String) { activity.runOnDownloadService { it.resume(id) } }

    @JavascriptInterface
    fun cancelNativeDownload(id: String) { activity.runOnDownloadService { it.cancel(id) } }

    @JavascriptInterface
    fun retryNativeDownload(id: String) { activity.runOnDownloadService { it.retry(id) } }

    @JavascriptInterface
    fun getDownloadStatus(id: String): String {
        var json = "null"
        activity.runOnDownloadService { service -> service.getItem(id)?.let { json = it.toJson() } }
        return json
    }

    @JavascriptInterface
    fun setSimultaneousLimit(limit: Int) { activity.runOnDownloadService { it.simultaneousLimit = limit } }

    @JavascriptInterface
    fun setSpeedLimitBytesPerSec(bytesPerSec: Double) {
        activity.runOnDownloadService { it.speedLimitBytesPerSec = bytesPerSec.toLong() }
    }

    // ---- Files ----

    @JavascriptInterface
    fun openDownloadedFile(id: String) { activity.runOnUiThread { activity.openDownloadedFile(id) } }

    @JavascriptInterface
    fun shareDownloadedFile(id: String) { activity.runOnUiThread { activity.shareDownloadedFile(id) } }

    // ---- Storage ----

    @JavascriptInterface
    fun chooseDownloadFolder() { activity.runOnUiThread { activity.launchFolderPicker() } }

    @JavascriptInterface
    fun getDownloadFolder(): String = StorageHelper.getFolderLabel(activity)

    @JavascriptInterface
    fun getStorageInfo(): String {
        val obj = JSONObject()
        obj.put("freeBytes", StorageHelper.freeSpaceBytes(activity))
        obj.put("folder", StorageHelper.getFolderLabel(activity))
        return obj.toString()
    }

    // ---- Permissions ----

    @JavascriptInterface
    fun requestNotificationPermission() { activity.runOnUiThread { activity.requestNotificationPermission() } }

    @JavascriptInterface
    fun requestOverlayPermission() { activity.runOnUiThread { activity.requestOverlayPermission() } }

    @JavascriptInterface
    fun isOverlayPermissionGranted(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(activity) else true

    // ---- Overlay ----

    @JavascriptInterface
    fun configureOverlay(sizeDp: Int, opacityPct: Int, position: String) {
        activity.getSharedPreferences("ydm_overlay_prefs", android.content.Context.MODE_PRIVATE).edit()
            .putInt("fab_size_dp", sizeDp)
            .putInt("fab_opacity_pct", opacityPct)
            .apply()
    }

    @JavascriptInterface
    fun startOverlay() {
        activity.runOnUiThread {
            if (isOverlayPermissionGranted()) OverlayService.start(activity)
            else activity.requestOverlayPermission()
        }
    }

    @JavascriptInterface
    fun stopOverlay() { OverlayService.stop(activity) }
}
