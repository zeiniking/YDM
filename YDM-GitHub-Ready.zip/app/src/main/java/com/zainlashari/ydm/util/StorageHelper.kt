package com.zainlashari.ydm.util

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.documentfile.provider.DocumentFile

/**
 * Wraps the user's chosen download folder.
 *
 * Preferred path: Storage Access Framework (SAF) tree Uri chosen via
 * Intent.ACTION_OPEN_DOCUMENT_TREE, persisted with a persistable URI permission.
 * This works on every Android version without any broad storage permission.
 *
 * Fallback: on API 28 and below where legacy external storage is still viable,
 * or when the user hasn't picked a folder yet, we fall back to the app's own
 * external files directory (no permission required at all) or MediaStore
 * Downloads collection on API 29+.
 */
object StorageHelper {

    private const val PREFS = "ydm_storage_prefs"
    private const val KEY_TREE_URI = "tree_uri"
    private const val KEY_LABEL = "tree_label"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun persistTreeUri(context: Context, uri: Uri) {
        context.contentResolver.takePersistableUriPermission(
            uri,
            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        val doc = DocumentFile.fromTreeUri(context, uri)
        prefs(context).edit()
            .putString(KEY_TREE_URI, uri.toString())
            .putString(KEY_LABEL, doc?.name ?: uri.lastPathSegment ?: "Chosen folder")
            .apply()
    }

    fun getTreeUri(context: Context): Uri? {
        val raw = prefs(context).getString(KEY_TREE_URI, null) ?: return null
        return Uri.parse(raw)
    }

    fun getFolderLabel(context: Context): String {
        return prefs(context).getString(KEY_LABEL, null)
            ?: if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) "Downloads (MediaStore)"
            else "App downloads folder"
    }

    /** Creates (or reuses) a destination document inside the chosen SAF folder. Returns null if no folder chosen. */
    fun createSafFile(context: Context, fileName: String, mimeType: String): DocumentFile? {
        val treeUri = getTreeUri(context) ?: return null
        val dir = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        dir.findFile(fileName)?.let { return it }
        return dir.createFile(mimeType, fileName)
    }

    /** App-private fallback directory; always writable, no permission needed. */
    fun fallbackDir(context: Context) =
        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: context.filesDir

    fun freeSpaceBytes(context: Context): Long {
        val stat = StatFs(fallbackDir(context).path)
        return stat.availableBytes
    }
}
