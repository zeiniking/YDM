package com.zainlashari.ydm.overlay

import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import com.zainlashari.ydm.MainActivity
import com.zainlashari.ydm.R
import com.zainlashari.ydm.util.NotificationHelper
import androidx.core.app.NotificationCompat

/**
 * A real system-wide floating overlay button (android.permission.SYSTEM_ALERT_WINDOW),
 * shown as an ongoing foreground service so Android doesn't kill it in the background.
 * Purely a native UI shortcut back into YDM — it has no access to, and does not
 * attempt to extract, any protected media stream.
 */
class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var params: WindowManager.LayoutParams? = null

    private lateinit var prefs: SharedPreferences

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("ydm_overlay_prefs", MODE_PRIVATE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Android 14+ requires every foreground service to declare a type and
        // the matching permission. specialUse is used because the overlay
        // shortcut is a user-enabled foreground service not covered by the
        // standard media/data-sync types.
        promoteToForeground()
        if (overlayView == null) showOverlay()
        return START_STICKY
    }

    private fun promoteToForeground() {
        val notification = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_STATUS)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle("YDM floating button")
            .setContentText("Floating download shortcut is active")
            .setOngoing(true)
            .setSilent(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                OVERLAY_NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(OVERLAY_NOTIFICATION_ID, notification)
        }
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_button, null)
        overlayView = view

        val sizeDp = prefs.getInt("fab_size_dp", 56)
        val opacityPct = prefs.getInt("fab_opacity_pct", 100)
        val sizePx = (sizeDp * resources.displayMetrics.density).toInt()

        val fab = view.findViewById<ImageView>(R.id.overlayFab)
        fab.layoutParams = fab.layoutParams.apply { width = sizePx; height = sizePx }
        fab.alpha = opacityPct / 100f

        val overlayType =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        // Start in a safe corner (avoids covering system status bar / gesture nav by default margin)
        lp.x = prefs.getInt("fab_x", 24)
        lp.y = prefs.getInt("fab_y", 200)
        params = lp

        attachDragHandling(view, lp)
        windowManager?.addView(view, lp)
    }

    private fun attachDragHandling(view: View, lp: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = lp.x; initialY = lp.y
                    touchX = event.rawX; touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 6 || kotlin.math.abs(dy) > 6) moved = true
                    lp.x = initialX + dx
                    lp.y = initialY + dy
                    windowManager?.updateViewLayout(view, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    prefs.edit().putInt("fab_x", lp.x).putInt("fab_y", lp.y).apply()
                    if (!moved) v.performClick()
                    true
                }
                else -> false
            }
        }
        view.setOnClickListener { openApp() }
    }

    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        overlayView?.let { runCatching { windowManager?.removeView(it) } }
        overlayView = null
        super.onDestroy()
    }

    companion object {
        private const val OVERLAY_NOTIFICATION_ID = 9002

        fun start(context: android.content.Context) {
            val intent = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
        fun stop(context: android.content.Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }
}
