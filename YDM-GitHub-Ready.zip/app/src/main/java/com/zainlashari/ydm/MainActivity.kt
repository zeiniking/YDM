package com.zainlashari.ydm

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.zainlashari.ydm.download.DownloadService
import com.zainlashari.ydm.model.DownloadItem
import com.zainlashari.ydm.onboarding.PermissionOnboardingActivity
import com.zainlashari.ydm.util.NotificationHelper
import com.zainlashari.ydm.util.StorageHelper
import com.zainlashari.ydm.util.UrlExtractor
import org.json.JSONObject
import java.io.File

class MainActivity : AppCompatActivity(), DownloadService.Listener {

    private lateinit var webView: WebView
    private lateinit var loadingSpinner: ProgressBar

    // WebView JavascriptInterface methods run on a background thread, while onServiceConnected
    // runs on the main thread — @Volatile keeps reads on the JS thread seeing the latest value.
    @Volatile
    private var downloadService: DownloadService? = null
    private var boundToService = false
    /** URL received before the WebView/bridge is ready is queued here. */
    private var pendingSharedUrl: String? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            downloadService = (binder as DownloadService.LocalBinder).getService()
            downloadService?.setListener(this@MainActivity)
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            downloadService = null
        }
    }

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* result observed via NotificationHelper.canPostNotifications() when needed */ }

    private val overlayPermLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { notifyWeb("AndroidBridge_onOverlayPermissionResult", isOverlayGranted().toString()) }

    private val folderPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { uri -> StorageHelper.persistTreeUri(this, uri) }
            notifyWeb("AndroidBridge_onFolderChosen", StorageHelper.getFolderLabel(this))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!PermissionOnboardingActivity.isComplete(this)) {
            startActivity(Intent(this, PermissionOnboardingActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webView)
        loadingSpinner = findViewById(R.id.loadingSpinner)
        setupWebView()

        // Start the service in a non-foreground state so the bound instance is
        // ready. It promotes itself to a foreground service only when a real
        // download is enqueued, so YDM stays quiet while idle.
        DownloadService.start(this)
        boundToService = bindService(Intent(this, DownloadService::class.java), connection, Context.BIND_AUTO_CREATE)

        handleIncomingIntent(intent, isColdStart = true)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent, isColdStart = false)
    }

    private fun setupWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        // Name must be "AndroidBridge" — YDM.html already looks for window.AndroidBridge.
        webView.addJavascriptInterface(WebAppInterface(this), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                loadingSpinner.visibility = android.view.View.GONE
                pendingSharedUrl?.let { url ->
                    deliverSharedUrlToWeb(url)
                    pendingSharedUrl = null
                }
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.loadUrl("file:///android_asset/YDM.html")
    }

    // ---------- Share intent handling ----------

    private fun handleIncomingIntent(intent: Intent, isColdStart: Boolean) {
        val url: String? = when (intent.action) {
            Intent.ACTION_SEND -> {
                val type = intent.type.orEmpty()
                if (type.startsWith("text/") || type == "text/plain" || type.isBlank()) {
                    val shared = intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                        ?: intent.getStringExtra(Intent.EXTRA_TEXT)
                    UrlExtractor.extractFirstUrl(shared)
                } else null
            }
            Intent.ACTION_VIEW -> {
                intent.data?.toString()?.takeIf { UrlExtractor.isHttpUrl(it) }
            }
            else -> null
        } ?: return

        if (isColdStart || !::webView.isInitialized) {
            // WebView may not have finished loading YDM.html yet; queue it for onPageFinished.
            pendingSharedUrl = url
        } else {
            deliverSharedUrlToWeb(url)
        }
    }

    private fun deliverSharedUrlToWeb(url: String) {
        val escaped = JSONObject.quote(url)
        webView.evaluateJavascript(
            "window.AndroidBridge_receiveSharedUrl && window.AndroidBridge_receiveSharedUrl($escaped);",
            null
        )
    }

    private fun notifyWeb(jsFunction: String, arg: String) {
        if (!::webView.isInitialized) return
        val escaped = JSONObject.quote(arg)
        runOnUiThread {
            webView.evaluateJavascript(
                "window.$jsFunction && window.$jsFunction($escaped);",
                null
            )
        }
    }

    // ---------- Permissions ----------

    fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !NotificationHelper.canPostNotifications(this)
        ) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun isOverlayGranted(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(this) else true

    fun requestOverlayPermission() {
        if (isOverlayGranted()) return
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        overlayPermLauncher.launch(intent)
    }

    fun launchFolderPicker() {
        folderPickerLauncher.launch(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE))
    }

    // ---------- Download service bridge helpers ----------

    fun runOnDownloadService(action: (DownloadService) -> Unit) {
        downloadService?.let(action)
    }

    // ---------- Notifications / files ----------

    fun showSimpleNotification(title: String, text: String) {
        if (!NotificationHelper.canPostNotifications(this)) return
        val notif = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_STATUS)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        nm.notify(title.hashCode(), notif)
    }

    fun openDownloadedFile(id: String) {
        val item = downloadService?.getItem(id) ?: return
        val uri = resolveContentUri(item) ?: return
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, item.mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { startActivity(intent) }
    }

    fun shareDownloadedFile(id: String) {
        val item = downloadService?.getItem(id) ?: return
        val uri = resolveContentUri(item) ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = item.mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, item.fileName))
    }

    private fun resolveContentUri(item: DownloadItem): Uri? {
        val dest = item.destinationUri ?: return null
        return if (dest.startsWith("content://")) {
            Uri.parse(dest)
        } else {
            FileProvider.getUriForFile(this, "$packageName.fileprovider", File(dest))
        }
    }

    // ---------- DownloadService.Listener ----------

    override fun onProgress(item: DownloadItem) {
        runOnUiThread {
            webView.evaluateJavascript(
                "window.AndroidBridge_onDownloadUpdate && window.AndroidBridge_onDownloadUpdate(${item.toJson()});",
                null
            )
        }
    }

    override fun onStateChanged(item: DownloadItem) {
        runOnUiThread {
            webView.evaluateJavascript(
                "window.AndroidBridge_onDownloadUpdate && window.AndroidBridge_onDownloadUpdate(${item.toJson()});",
                null
            )
        }
    }

    override fun onDestroy() {
        if (boundToService) unbindService(connection)
        super.onDestroy()
    }
}
