package com.zainlashari.ydm.onboarding

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.zainlashari.ydm.MainActivity
import com.zainlashari.ydm.R
import com.zainlashari.ydm.util.StorageHelper

/**
 * First-launch walkthrough: explains and requests, one at a time, exactly the
 * permissions YDM uses (notifications, a chosen download folder, optional overlay).
 * No unrelated permissions are requested here.
 */
class PermissionOnboardingActivity : AppCompatActivity() {

    private enum class Step { NOTIFICATIONS, STORAGE, OVERLAY, DONE }
    private var step = Step.NOTIFICATIONS

    private lateinit var prefs: SharedPreferences

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { advance() }

    private val folderPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri: Uri -> StorageHelper.persistTreeUri(this, uri) }
        }
        advance()
    }

    private val overlaySettingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { advance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)
        prefs = getSharedPreferences("ydm_onboarding_prefs", MODE_PRIVATE)

        findViewById<android.widget.Button>(R.id.onboardContinueBtn).setOnClickListener { onContinue() }
        findViewById<android.widget.Button>(R.id.onboardSkipBtn).setOnClickListener { advance() }

        renderStep()
        // Start the permission flow automatically on first launch. System dialogs
        // and the SAF picker still require the user's explicit confirmation.
        window.decorView.postDelayed({ requestCurrentStepAutomatically() }, 300)
    }

    private fun requestCurrentStepAutomatically() {
        when (step) {
            Step.NOTIFICATIONS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    androidx.core.content.ContextCompat.checkSelfPermission(
                        this, Manifest.permission.POST_NOTIFICATIONS
                    ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    advance()
                }
            }
            Step.STORAGE -> {
                // SAF is a user-selected folder, so Android must show its picker.
                folderPickerLauncher.launch(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE))
            }
            Step.OVERLAY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    overlaySettingsLauncher.launch(intent)
                } else {
                    advance()
                }
            }
            Step.DONE -> finishOnboarding()
        }
    }

    private fun onContinue() {
        when (step) {
            Step.NOTIFICATIONS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else advance()
            }
            Step.STORAGE -> {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                folderPickerLauncher.launch(intent)
            }
            Step.OVERLAY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    overlaySettingsLauncher.launch(intent)
                } else advance()
            }
            Step.DONE -> finishOnboarding()
        }
    }

    private fun advance() {
        step = when (step) {
            Step.NOTIFICATIONS -> Step.STORAGE
            Step.STORAGE -> Step.OVERLAY
            Step.OVERLAY -> Step.DONE
            Step.DONE -> Step.DONE
        }
        if (step == Step.DONE) finishOnboarding() else renderStep()
    }

    private fun renderStep() {
        val title = findViewById<android.widget.TextView>(R.id.onboardStepTitle)
        val desc = findViewById<android.widget.TextView>(R.id.onboardStepDesc)
        when (step) {
            Step.NOTIFICATIONS -> {
                title.text = getString(R.string.onboarding_notif_title)
                desc.text = getString(R.string.onboarding_notif_desc)
            }
            Step.STORAGE -> {
                title.text = getString(R.string.onboarding_storage_title)
                desc.text = getString(R.string.onboarding_storage_desc)
            }
            Step.OVERLAY -> {
                title.text = getString(R.string.onboarding_overlay_title)
                desc.text = getString(R.string.onboarding_overlay_desc)
            }
            Step.DONE -> finishOnboarding()
        }
    }

    private fun finishOnboarding() {
        prefs.edit().putBoolean("onboarding_complete", true).apply()
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    companion object {
        fun isComplete(context: android.content.Context): Boolean =
            context.getSharedPreferences("ydm_onboarding_prefs", MODE_PRIVATE)
                .getBoolean("onboarding_complete", false)
    }
}
