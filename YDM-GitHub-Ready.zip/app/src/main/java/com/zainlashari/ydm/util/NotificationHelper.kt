package com.zainlashari.ydm.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.zainlashari.ydm.R

object NotificationHelper {

    const val CHANNEL_PROGRESS = "ydm_download_progress"
    const val CHANNEL_STATUS = "ydm_download_status"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val progress = NotificationChannel(
            CHANNEL_PROGRESS,
            context.getString(R.string.notif_channel_progress),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            setShowBadge(false)
        }

        val status = NotificationChannel(
            CHANNEL_STATUS,
            context.getString(R.string.notif_channel_status),
            NotificationManager.IMPORTANCE_DEFAULT
        )

        nm.createNotificationChannel(progress)
        nm.createNotificationChannel(status)
    }

    /** True if we are allowed to post notifications right now (handles the API 33+ runtime permission). */
    fun canPostNotifications(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.POST_NOTIFICATIONS
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
}
