# Keep the JS bridge: methods called from WebView JS must survive R8/ProGuard.
-keepclassmembers class com.zainlashari.ydm.WebAppInterface {
    public *;
}
-keep class com.zainlashari.ydm.model.** { *; }
