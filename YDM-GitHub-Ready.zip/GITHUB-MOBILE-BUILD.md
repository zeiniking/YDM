# YDM - Mobile Cloud Build

This project includes a GitHub Actions workflow at `.github/workflows/android-build.yml`.

After the project is uploaded to a GitHub repository:

1. Open the repository in Chrome.
2. Open **Actions**.
3. Select **YDM Android Build**.
4. Tap **Run workflow** and run it from the default branch.
5. Wait for the green check.
6. Open the completed run.
7. Under **Artifacts**, download **YDM-builds**.
8. Extract the artifact ZIP. It contains the debug APK and release AAB.

The workflow uses JDK 17, the Gradle wrapper included with the project, and GitHub-hosted runners. It does not require Android Studio on the phone.
