# YDM — Native Android Wrapper

A real Android Studio project (Kotlin) that wraps your existing `YDM.html` in a
native shell, adding: Share-Sheet integration, a native background download
engine, a native floating overlay button, notifications, and Storage Access
Framework / MediaStore-based file storage.

**Your `YDM.html` was not redesigned.** It's unmodified in every visual and
structural respect — same UI, same screens, same in-page fetch-based download
engine as a browser-mode fallback. The only edits made to it were small,
additive hooks (clearly commented, search for `AndroidBridge`) so the page can
hand off to the native engine when one is present, exactly the way its own
`bridge()` helper was already designed to be used.

---

## 1. Project structure

```
YDM-Android/
├── app/
│   ├── src/main/
│   │   ├── assets/YDM.html              ← your app, lightly hooked (see below)
│   │   ├── java/com/zainlashari/ydm/
│   │   │   ├── MainActivity.kt          ← WebView host, share-intent handling
│   │   │   ├── WebAppInterface.kt       ← JS bridge (window.AndroidBridge)
│   │   │   ├── YdmApplication.kt        ← notification channel setup
│   │   │   ├── download/DownloadService.kt   ← native download engine
│   │   │   ├── overlay/OverlayService.kt     ← floating button
│   │   │   ├── onboarding/PermissionOnboardingActivity.kt
│   │   │   ├── util/StorageHelper.kt    ← SAF/MediaStore folder handling
│   │   │   ├── util/NotificationHelper.kt
│   │   │   └── util/UrlExtractor.kt     ← pulls a URL out of shared text
│   │   ├── res/                         ← layouts, icons, strings
│   │   └── AndroidManifest.xml          ← share target, permissions, services
│   └── build.gradle.kts
├── build.gradle.kts
└── settings.gradle.kts
```

### What changed inside YDM.html, and why

Your file already contained the right seams for this (`window.AndroidBridge`,
a `bridge(method, ...args)` helper, and `window.AndroidBridge_receiveSharedUrl`).
The edits:

1. `bridge("showNotification", {kind,title,body})` → `bridge("showNotification", kind, title, body)`.
   WebView's JS bridge can only marshal primitive arguments, not object literals,
   so this was a required signature fix, not a redesign.
2. `startDownloadItem()` now tries `AndroidBridge.startNativeDownload(...)` first;
   if a native id comes back, the native engine drives that download (progress,
   completion, pause/resume/cancel/retry) and the existing in-page `fetch()` loop
   is skipped for that item. In a plain browser (no `AndroidBridge`), nothing
   changes — the original fetch-based engine still runs exactly as before.
3. `pauseDownload` / `resumeDownload` / `cancelDownload` / `retryDownload` route to
   `pauseNativeDownload` / etc. when an item has a native id.
4. Settings → simultaneous downloads / speed limit / choose folder / floating
   button now also inform the native engine (`setSimultaneousLimit`,
   `setSpeedLimitBytesPerSec`, `chooseDownloadFolder`, `startOverlay`/`stopOverlay`).
5. A few small `window.AndroidBridge_on*` callback handlers were added
   (`onDownloadUpdate`, `onFolderChosen`, `onOverlayPermissionResult`) so native
   code can push results back into the page.

No screens, styles, features, or existing logic were removed.

---

## 2. Important native fixes included

This build includes the native fixes needed for the requested workflow: the Share Sheet receiver accepts `text/*` and extracts the URL from `EXTRA_TEXT`; first-launch permissions begin automatically (the user still confirms Android system dialogs and the folder picker); the floating overlay is a real Android foreground service with the Android 14+ `specialUse` declaration; and the native downloader no longer corrupts a partial file when a server ignores a Range resume request.

A YouTube `watch`/`shorts` page URL is still not a direct media file URL. YDM deliberately does not bypass DRM, authentication, signatures, or protected-stream restrictions.

## 3. Opening in Android Studio

1. Install **Android Studio Ladybug (2024.2)** or newer, with Android SDK
   Platform 34 and Build-Tools 34 installed via the SDK Manager.
2. `File → Open…` and select the `YDM-Android` folder (the one containing
   `settings.gradle.kts`).
3. Let Gradle sync. First sync downloads the Gradle 8.7 wrapper and all
   dependencies — this needs network access.
4. If you're prompted to update AGP/Gradle, you can accept; the project pins
   AGP 8.5.2 / Kotlin 1.9.24 / Gradle 8.7, a known-good combination.

## 4. Adding / updating YDM.html

`app/src/main/assets/YDM.html` is already in place with the hooks described
above. To update it with a newer version of your app later:

1. Replace `app/src/main/assets/YDM.html` with your new file.
2. Re-apply the small `AndroidBridge` hooks listed above (search the old file
   for `AndroidBridge` to see exactly what to carry over), or ask for the same
   patch to be regenerated against the new file.

## 5. Building an APK

- **Debug APK (fastest, for testing):**
  `Build → Build App Bundle(s) / APK(s) → Build APK(s)`, or from the terminal:
  ```
  ./gradlew assembleDebug
  ```
  Output: `app/build/outputs/apk/debug/app-debug.apk`

- **Release APK (signed):**
  `Build → Generate Signed Bundle / APK… → APK`, create or select a keystore,
  and build the `release` variant. Or via terminal after configuring signing
  in `app/build.gradle.kts`:
  ```
  ./gradlew assembleRelease
  ```

## 6. Building an AAB (for Play Store)

`Build → Generate Signed Bundle / APK… → Android App Bundle`, using the same
keystore. Or:
```
./gradlew bundleRelease
```
Output: `app/build/outputs/bundle/release/app-release.aab`

---

## 7. Testing checklist

### Share → YDM
1. Install the app on a device/emulator (API 24+).
2. Open any app that can share a link (browser, YouTube app, Messages) and
   share some `https://…` text.
3. **YDM** should appear in the system Share Sheet.
4. Tap it. YDM opens (cold start or resumes if already running) and the URL
   should already be filled into the URL field — no manual paste.
5. Test with text that has extra words around the link
   (e.g. "check this out: https://example.com/file.mp4 thanks!") to confirm
   `UrlExtractor` pulls just the URL.
6. Test both with the app fully closed (cold start, exercises `onCreate`) and
   with the app already open in the background (exercises `onNewIntent`).

### Overlay permission / floating button
1. In YDM, go to Settings and enable **Floating Download Button**.
2. If "Display over other apps" isn't yet granted, Android's system settings
   screen for that permission should open automatically.
3. Grant it, return to YDM — the floating button should appear.
4. Leave YDM (press Home or open another app) — the button should still float
   on screen, be draggable, stay within screen bounds, and tapping it should
   reopen YDM.
5. Turn the setting off — the overlay should disappear.

### Downloads
1. Paste a direct, authorized file URL (not a YouTube watch page — the app
   deliberately does not treat those as direct downloadable URLs).
2. Start a download and confirm progress, speed, and ETA update live.
3. Pause mid-download, then resume — confirm it continues from where it left
   off rather than restarting (byte-range resume).
4. Cancel a download and confirm the partial file is cleaned up.
5. Force a failure (e.g. airplane mode mid-download) and confirm **Retry**
   restarts it.
6. Change **Simultaneous downloads** and **Speed limit** in Settings and
   confirm new downloads respect them.
7. Use **Change** under download location to pick a folder via the system
   picker (Storage Access Framework) — confirm subsequent downloads land
   there.

### Notifications
1. On Android 13+, the notification permission prompt should appear the first
   time a notification-related setting is turned on (or during first-launch
   onboarding).
2. Start a download and confirm a progress notification appears and updates.
3. Let a download complete/fail and confirm the corresponding "done"/"failed"
   notification appears.
4. Deny the permission once — confirm YDM does not repeatedly re-prompt.

---

## 8. What this project intentionally does NOT do

Per your requirements, it does not implement DRM bypass, protected-stream
decryption, signature bypass, authentication bypass, or unauthorized
extraction of protected streams (e.g. from YouTube watch pages). The native
download engine only fetches the exact URL it's given, the same restriction
already documented in YDM.html's own Terms text.
